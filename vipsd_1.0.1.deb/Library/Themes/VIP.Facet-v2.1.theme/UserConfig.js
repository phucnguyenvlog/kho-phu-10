
/* ********* Configure Your Weather Widget here ********* */
/* Step 1 - Find YOUR city code (locale) here : http://www.edg3.co.uk/snippets/weather-location-codes/

Some Examples :
UKXX0085=London
USNY0996=NYC
USCA0638=LA
USNV0049=Vegas
USCA0987=Frisco
FRXX0023=Cannes
ITXX0042=Milan
*/

/* Step 2 - Then enter your city code here */
var locale = "VMXX0006" 

/* Use Celsius or not */
var isCelsius = true

/* Use Real Feel Temperature or not */
var useRealFeel = false

/* Minutes between updates */
var updateInterval = 10


/* ****************************************************** */



//Toggles twelve and twenty-four hour time.
var twentyFourHourTime = false;


//This affects the calendar.
function updateCalendarBar() {
	var theDate = new Date();
	var theWeekday = theDate.getDay();
	var theMonth = theDate.getMonth();
	var theDay = theDate.getDate();
	var weekdaysArray = new Array();
	
	//Change the Weekdays here
	weekdaysArray[0] = "SUNDAY";
	weekdaysArray[1] = "MONDAY";
	weekdaysArray[2] = "TUESDAY";
	weekdaysArray[3] = "WEDNESDAY";
	weekdaysArray[4] = "THURSDAY";
	weekdaysArray[5] = "FRIDAY";
	weekdaysArray[6] = "SATURDAY";
	theWeekday = weekdaysArray[theWeekday];
	var monthsArray = new Array();
	
	//Change the Months here
	monthsArray[0] = "JAN";
	monthsArray[1] = "FEB";
	monthsArray[2] = "MAR";
	monthsArray[3] = "APR";
	monthsArray[4] = "MAY";
	monthsArray[5] = "JUN";
	monthsArray[6] = "JUL";
	monthsArray[7] = "AUG";
	monthsArray[8] = "SEP";
	monthsArray[9] = "OCT";
	monthsArray[10] = "NOV";
	monthsArray[11] = "DEC";
	
	theMonth = monthsArray[theMonth];
	if (theDay < 10) {theDay = "0" + theDay};
	var formattedDays = String(theDay);
	formattedDays = formattedDays.split("");
	document.getElementById("week").innerHTML = "<span></span>" +theWeekday;
	document.getElementById("month").innerHTML = "<span></span>" +theMonth;
	document.getElementById("day").innerHTML = "<span></span>" +theDay;
}
