/* *************************************** */
/* The following scripts will allow you to finetune */
/* *************************************** */

/* *************************************** */
/* **************** CLOCK & LANGUAGE **************** */

//Toggles twelve and twenty-four hour time.
var twentyFourHourTime = false;


//Toggles between English and French
var languageEnglish = true;

			
/* *************************************** */
