/* *************************************** */
/* The following scripts will allow you to finetune */

/* *************************************** */

/* ********* Configure Your Weather Widget here ********* */
/* Step 1 - Find YOUR city code (locale) here : http://www.edg3.co.uk/snippets/weather-location-codes/

Some Examples :
USNY0996 = NYC, US
USCA0638 = LA, US
USNV0049 = Vegas, US
USCA0987 = Frisco, US
FRXX0076 = Paris, FR
FRXX0059 = Marseille, FR
CAXX0301 = Montreal, CA
UKXX0085 = London, UK
ITXX0042 = Milan, IT
*/

/* Step 2 - Then enter your city code here */
var locale = "VMXX0006" 

/* Use Celsius or not */
var isCelsius = true

/* Use Real Feel Temperature or not */
var useRealFeel = false

/* Minutes between updates */
var updateInterval = 15


/* ****************************************************** */

/* **************** CLOCK & LANGUAGE **************** */

//Toggles twelve and twenty-four hour time.
var twentyFourHourTime = true;


//Toggles between English and French
var languageEnglish = true;

			
