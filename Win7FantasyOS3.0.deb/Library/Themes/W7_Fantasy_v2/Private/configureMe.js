﻿// WeatherWidget.theme
// Produced by Adam Watkins (http://www.stupidpupil.co.uk)

// The location field should be a relatively machine-legible string
// if using the default, Apple/AccuWeather parser (originally from Leopard's Weather.wdgt)
var locale = "VMXX0006" //e.g. 'Los Angeles, CA = 90033'|'Netherlands = NLXX0016' | 'London = UKXX0085'

// Set to 'false' if you'd prefer Farenheit
var isCelsius = true //true|false

// Use 'Real Feel' temperatures where possible, taking into account Wind Chill, Humidity etc.
var useRealFeel = false //true|false

/*––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––*/
//Enable Wallpaper and/or Lock Screen
var enableWallpaper = true; //true|false
var enableLockScreen = false; //true|false [Currently, it is suggested that the lockScreen is disabled.]

// Supplied styles are 'originalBubble', 'myopia', 'iconOnly' and 'split'.
// (Add your own to the CSS folder!)
var stylesheetWall = 'WIN 7_BlissAliveWeather' //'originalBubble'|'myopia'|'iconOnly'|'split'|'oneLine'
var stylesheetLock = 'WIN 7_BlissAliveWeather' //See above.

// The only supplied icon set is 'klear'
// Images must follow the same naming schema as the 'klear' set (borrowed from KWeather)
var iconSetWall = 'WIN 7_BlissAliveWeather' //'klear'|'tango'
var iconExtWall = '.png' //'.png'|.'png' etc.
var iconSetLock = 'WIN 7_BlissAliveWeather' //See above.
var iconExtLock = '.png' //See above.


/*––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––*/

// The other available source is 'yahooWeather' which for the 'locale'
// requires a US zip or location code (e.g. UKXX0085 or CHXX0008) from http://weather.yahoo.com
var source = 'yahooWeather' //'appleAccuweatherStolen'|'yahooWeather'

// Please endeavour to set this to a sensible value if you really must change it...
var updateInterval = 5 //Minutes