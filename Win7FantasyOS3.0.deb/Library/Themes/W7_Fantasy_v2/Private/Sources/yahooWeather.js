var MiniIcons =
[
	"0",		       //0 	tornado
	"1",		       //1 	tropical storm
	"2",		       //2 	hurricane
	"3",		       //3 	severe thunderstorms
	"4",		       //4 	thunderstorms
	"5",		       //5 	mixed rain and snow
	"6",		       //6 	mixed rain and sleet
	"7",		       //7 	mixed snow and sleet
	"8",		       //8 	freezing drizzle
	"9",		       //9 	drizzle
	"10",		       //10 	freezing rain
	"11",		       //11 	showers
	"12",		       //12 	showers
	"13",		       //13 	snow flurries
	"14",		       //14 	light snow showers
	"15",		       //15 	blowing snow
	"16",		       //16 	snow
	"17",		       //17 	hail
	"17",		       //18 	sleet
	"19",		       //19 	dust
	"20",		       //20 	foggy
	"21",		       //21 	haze
	"22",		       //22 	smoky
	"23",		       //23 	blustery
	"24",		       //24 	windy
	"25",		       //25 	cold
	"26",		       //26 	cloudy
	"27",	              //27 	mostly cloudy (night)
	"28",		       //28 	mostly cloudy (day)
	"29",	              //29 	partly cloudy (night)
	"30",		       //30 	partly cloudy (day)
	"31",	              //31 	clear (night)
	"32",		       //32 	sunny
	"33",		       //33 	fair (night)
	"34",		       //34 	fair (day)
	"35",		       //35 	mixed rain and hail
	"36",		       //36 	hot
	"37",		       //37 	isolated thunderstorms
	"38",		       //38 	scattered thunderstorms
	"39",		       //39 	scattered thunderstorms
	"40",		       //40 	scattered showers
	"41",		       //41 	heavy snow
	"42",		       //42 	scattered snow showers
	"43",		       //43 	heavy snow
	"44",		       //44 	partly cloudy
	"45",		       //45 	thundershowers
	"46",		       //46 	snow showers
	"47",		       //47 	isolated thundershowers
	"dunno",		//3200 not available
]

function constructError (string)
{
	return {error:true, errorString:string};
}

function findChild (element, nodeName)
{
	var child;
	
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	
	return null;
}


function fetchWeatherData (callback, zip)
{
	url="http://weather.yahooapis.com/forecastrss?u=f&p=" //u=Farenheit, because accuWeather sucks
	
	var xml_request = new XMLHttpRequest();
	xml_request.onload = function(e) {xml_loaded(e, xml_request, callback);}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url+zip);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);	
	
	return xml_request;
}

function xml_loaded (event, request, callback)
{
	if (request.responseXML)
	{
	 	var obj = {error:false, errorString:null};
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city");
		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");//Only accounts for windChill
		
		conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text"); 
		callback (obj); 
	}else{
		callback ({error:true, errorString:"XML request failed. no responseXML"});
	}
}


function validateWeatherLocation (location, callback)
{
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location}; //Not very clever, are we?
	callback (obj);
}