
var updateInterval = "20"; //weather refresh in minutes

var tempUnit = "f"; 

var locale = "689996"; 

var gps = "false"; //needs WidgetWeather from Cydia

var UseNeighborhood = "false";

var UseCityGPS = "false";
