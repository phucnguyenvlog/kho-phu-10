
// Try to update the page any X minutes when internet connection is disabled.
var updateIntervalOff = 1;

// Show image? (yes = true, no = false), if true, you won't be able to limit the max letters per description.
var ShowPI = true;

// Special support for hebrew (if your main language is hebrew -> true, else -> false)
var hebrew = false;

// Do you want the widget to be right to left? (yes -> true, no -> false)
var rtl = false;